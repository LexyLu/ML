%PMTKtitle DPmixturesTeh: Dirichlet process mixture models
%PMTKurl  http://www.gatsby.ucl.ac.uk/~ywteh/teaching/npbayes/mlss2007.zip
%PMTKauthor Yee Whye Teh
%PMTKdate 2007
