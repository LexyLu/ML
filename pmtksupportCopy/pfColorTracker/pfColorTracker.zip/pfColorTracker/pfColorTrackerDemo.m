%PMTKslow
loadData('rcHelicopterTrackingVideo', 'isMatFile', false) % download from pmtkdata.googlecode.com
setSeed(0);
test_pf_colortracker % original function
