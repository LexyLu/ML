%PMTKtitle pfColorTracker: particle filtering for isually tracking single object
%PMTKauthor Sebastien Paris
%PMTKurl http://www.mathworks.com/matlabcentral/fileexchange/17960
%PMTKdate December 2010

